module.exports = {
    PORT: 3000,
    DB: 'mongodb://localhost:27017/TestDB',
    sessionOpts: {
        saveUninitialized: true, // saved new sessions
        resave: false, // do not automatically write to the session store
        secret: 'topsecret',
        store: '',
        cookie: {httpOnly: true, maxAge: 2419200000} // configure when sessions expires
    }
};

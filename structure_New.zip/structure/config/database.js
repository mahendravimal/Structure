const mongoose = require('mongoose');
const dbURL = require('./properties').DB;
mongoose.set('useNewUrlParser', true);
mongoose.set('useCreateIndex', true);
module.exports = () => {
    mongoose.connect(dbURL);
    const db = mongoose.connection;
    db.on('connected', function () {
        console.log("Mongoose default connection is open to ", dbURL);
    });
    db.on('error', function (err) {
        console.log(error("Mongoose default connection has occured " + err + " error"));
    });

    db.on('disconnected', function () {
        console.log("Mongoose default connection is disconnected");
    });

    process.on('SIGINT', function () {
        db.close(function () {
            console.log("Mongoose default connection is disconnected due to application termination");
            process.exit(0)
        });
    });

    return db;
};

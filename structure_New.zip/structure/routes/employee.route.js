const Users = require('../controllers/employee.controller');
const express = require('express');
const router = express.Router();


// router.post('/create', Users.createUserRole);
router.get('/get', Users.getUserRole);
// router.get('/get/:name', Users.getUserRole);
// router.put('/update/:id', Users.updateUserRole);
// router.delete('/remove/:id', Users.removeUserRole);
module.exports = router;

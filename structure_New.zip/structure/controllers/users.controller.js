const Users = require('../models/users.dao');
const passport = require('passport');

exports.createUser = function (req, res, next) {
    Users.create(user, function (err, user) {
        if (err) {
            return res.status(500).json({
                error: err
            })
        }
        res.json({
            message: "User created successfully"
        })
    });
};

exports.registerUser = (req, res, next) => {
    const user = req.body;
    if (user.password === user.confirmPassword) {
        Users.register(new Users(user),
            req.body.password, (err, user) => {
                if (err) {
                    res.statusCode = 500;
                    res.setHeader('Content-Type', 'application/json');
                    res.json({
                        err: err
                    });
                } else {
                    passport.authenticate('local')(req, res, () => {
                        Users.getByName({
                            username: req.body.username
                        }, (err, user) => {
                            res.statusCode = 200;
                            res.setHeader('Content-Type', 'application/json');
                            res.json({
                                success: true,
                                status: 'Registration Successful!',
                                user: user,
                                reqUser: req.user
                            });
                        });
                    })
                }
            });
    } else {
        res.status(500).send("{errors: \"Passwords don't match\"}").end()
    }
};

exports.getUsers = function (req, res, next) {
    Users.get({}, function (err, users) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            users: users
        })
    })
};

exports.getUser = function (req, res, next) {
    Users.getByName({loginName: req.params.loginName}, function (err, user) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            user: user,
        })
    })
};

exports.updateUser = function (req, res, next) {
    const user = req.body;
    Users.update({_id: req.params.id}, user, function (err, user) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            message: "User updated successfully"
        })
    })
};

exports.removeUser = function (req, res, next) {
    Users.delete({_id: req.params.id}, function (err, user) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            message: "User deleted successfully"
        })
    })
};

exports.login = function (req, res, next) {
    Users.getByName({
        username: req.body.username
    }, (err, user) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json({
            success: true,
            status: 'You are successfully logged in!',
            reqUser: req.user,
            sessionId: req.session
        });
    })
};

exports.logout = function (req, res, next) {
    if (req.session && req.session.passport) {
        req.logout();
        req.session.destroy((err) => {
            if (err) {
                console.log(err);
            } else {
                res.clearCookie('session-id');
                res.json({
                    message: 'You are successfully logged out!'
                });
            }
        });
    } else {
        const err = new Error('You are not logged in!');
        err.status = 403;
        next(err);
    }
};

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const usersRoleSchema = new Schema({
    roleName: {
        type: String,
        required: true,
        unique: true,
        trim: true,
    },
    description: {
        type: String,
        trim: true
    }
}, {
    timestamps: true,
});

module.exports = usersRoleSchema;

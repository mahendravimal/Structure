const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const employeeschema = new Schema({
    Id: {type: String },
    Name: {type: String},
    LastName: {type: String},
    DOB: {type: String},
    Gender: {type: String}
});

module.exports = employeeschema;

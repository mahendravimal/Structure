const mongoose = require('mongoose');
const usersRoleSchema = require('../schemas/usersRole.schema');

usersRoleSchema.statics = {
    create: function (data, cb) {
        const userRole = new this(data);
        userRole.save(cb);
    },

    get: function (query, cb) {
        this.find(query, cb);
    },

    getByName: function (query, cb) {
        this.find(query, cb);
    },

    update: function (query, updateData, cb) {
        this.findOneAndUpdate(query, {$set: updateData}, {new: true}, cb);
    },

    delete: function (query, cb) {
        this.findOneAndDelete(query, cb);
    }

};

const usersRoleModel = mongoose.model('UsersRole', usersRoleSchema);
module.exports = usersRoleModel;

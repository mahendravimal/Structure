const mongoose = require('mongoose');
const usersSchema = require('../schemas/users.schema');
const passportLocalMongoose = require('passport-local-mongoose');
usersSchema.statics = {
    create: function (data, cb) {
        const newUser = new this(data);
        newUser.save(cb);
    },

    get: function (query, cb) {
        this.find(query, cb);
    },

    getByName: function (query, cb) {
        this.find(query, cb);
    },

    update: function (query, updateData, cb) {
        this.findOneAndUpdate(query, {$set: updateData}, {new: true}, cb);
    },

    delete: function (query, cb) {
        this.findOneAndDelete(query, cb);
    },

}
;
usersSchema.plugin(passportLocalMongoose);
const usersModel = mongoose.model('Users', usersSchema);
module.exports = usersModel;

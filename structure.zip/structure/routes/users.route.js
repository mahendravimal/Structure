const Users = require('../controllers/users.controller');
const express = require('express');
const router = express.Router();
const passport = require('passport');

router.post('/create', Users.createUser);
router.post('/signup', Users.registerUser);
router.get('/get', Users.getUsers);
router.post('/login', passport.authenticate('local'), Users.login);
router.get('/logout', Users.logout);

router.get('/get/:name', Users.getUser);
router.put('/update/:id', Users.updateUser);
router.delete('/remove/:id', Users.removeUser);
module.exports = router;

const mongoose = require('mongoose');
const isEmail = require('validator').isEmail;
const Schema = mongoose.Schema;
const userSchema = new Schema({
    userAdId: {
        type: String,
        trim: true,
    },
    userFullName: {
        type: String,
        trim: true,
    },
    firstName: {
        type: String,
        trim: true,
    },
    lastName: {
        type: String,
        trim: true,
    },
    departmentId: {
        type: String,
        trim: true,
    },
    username: {
        type: String,
        required: true,
        unique: true,
        sparse: true,
        validate: {validator: isEmail},
        trim: true,
    },
    mobileToken: {
        type: String,
        unique: true,
        sparse: true,
        index: true,
        trim: true,
    }
}, {
    timestamps: true,
});
module.exports = userSchema;

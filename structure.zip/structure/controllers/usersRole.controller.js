const UsersRole = require('../models/usersRole.dao');

exports.createUserRole = function (req, res, next) {
    const userRoleBody = req.body;

    UsersRole.create(userRoleBody, function (err, userRoleCreated) {
        if (err) {
            return res.status(500).json({
                error: err
            })
        }
        res.json({
            message: "UserRole created successfully",
            newUserRole: userRoleCreated
        })
    })
};

exports.getUsersRole = function (req, res, next) {
    UsersRole.get({}, function (err, users) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            usersRole: users
        })
    })
};

exports.getUserRole = function (req, res, next) {
    UsersRole.getByName({name: req.params.name}, function (err, users) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            users: users
        })
    })
};

exports.updateUserRole = function (req, res, next) {
    const userRoleBody = req.body;
    UsersRole.update({_id: req.params.id}, userRoleBody, function (err, userRole) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            message: "user role updated successfully",
            updatedUserRole: userRole
        })
    })
};

exports.removeUserRole = function (req, res, next) {
    UsersRole.delete({_id: req.params.id}, function (err, user) {
        if (err) {
            res.json({
                error: err
            })
        }
        res.json({
            message: "UserRole deleted successfully",
            deletedUser: user
        });
    })
};
